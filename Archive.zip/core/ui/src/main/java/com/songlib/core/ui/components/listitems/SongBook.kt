package com.songlib.core.ui.components.listitems

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.songlib.core.common.utils.refineTitle
import com.songlib.core.database.model.BookEntity
import com.songlib.core.ui.sample.SampleBooks
import com.songlib.core.common.entity.Selectable

@Composable
fun SongBook(
    item: Selectable<BookEntity>,
    onClick: (Selectable<BookEntity>) -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor =
        if (item.isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.inversePrimary
    val txtColor =
        if (item.isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.scrim

    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(2.dp)
            .clickable { onClick(item) },
        colors = CardDefaults.cardColors(
            containerColor = bgColor,
            contentColor = txtColor,
        ),
        elevation = CardDefaults.cardElevation(5.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = buildAnnotatedString {
                    withStyle(style = SpanStyle(fontSize = 18.sp, color = txtColor)) {
                        append(refineTitle(item.data.title))
                    }
                    append(" ")
                    withStyle(style = SpanStyle(fontSize = 14.sp, color = txtColor.copy(alpha = 0.7f))) {
                        append("(${item.data.songs})")
                    }
                },
                maxLines = 3
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewSongBook() {
    val sampleBook = SampleBooks[0]

    val selectableBook = Selectable(data = sampleBook, isSelected = true)

    SongBook(
        item = selectableBook,
        onClick = {}
    )
}
