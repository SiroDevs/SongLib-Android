package com.songlib.feature.selection

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.songlib.core.common.entity.Selectable
import com.songlib.core.common.entity.UiState
import com.songlib.core.data.repos.PrefsRepo
import com.songlib.core.data.repos.SongBookRepo
import com.songlib.core.database.model.BookEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import javax.inject.Inject

@HiltViewModel
class SelectionViewModel @Inject constructor(
    private val prefsRepo: PrefsRepo,
    private val songbkRepo: SongBookRepo,
) : ViewModel() {
    private val _uiState = MutableStateFlow<UiState>(UiState.Loading)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _books = MutableStateFlow<List<Selectable<BookEntity>>>(emptyList())
    val books: StateFlow<List<Selectable<BookEntity>>> get() = _books

    private fun getSelectedIds(): Set<Int> =
        prefsRepo.selectedBooks
            .split(",")
            .mapNotNull { it.toIntOrNull() }
            .toSet()

    fun fetchBooks() {
        _uiState.tryEmit(UiState.Loading)

        viewModelScope.launch {
            songbkRepo.fetchRemoteBooks().catch { exception ->
                Log.d("TAG", "fetching books error")
                val errorMessage = when (exception) {
                    is HttpException -> "Oops! We can't access the songbooks at the moment due to a HTTP Error: ${exception.code()} error on our server. Kindly try again a little later."
                    else -> "Oops! We can't access the songbooks at the moment due to a ${exception.message} error on our server. Kindly try again a little later."
                }
                Log.d("TAG", errorMessage)
                _uiState.tryEmit(UiState.Error(errorMessage))
            }.collect { respData ->
                val selectableBooks = respData.map { book->
                    Selectable(book, book.bookId in getSelectedIds())
                }
                _books.emit(selectableBooks)
                Log.d("TAG", "${_books.value.size} books fetched")
                _uiState.tryEmit(UiState.Loaded)
            }
        }
    }

    fun getSelectedBookList(): List<BookEntity> {
        return _books.value.filter { it.isSelected }.map { it.data }
    }

    fun saveSelectedBooks() {
        saveBooks(getSelectedBookList())
    }

    private fun saveBooks(books: List<BookEntity>) {
        _uiState.tryEmit(UiState.Saving)
        Log.d("TAG", "saving ${books.size} books")

        viewModelScope.launch {
            try {
                if (prefsRepo.selectAfresh) {
                    val existingIds = getSelectedIds()
                    val newIds = books.map { it.bookId }.toSet()

                    val booksToInsert = books.filter { it.bookId !in existingIds }
                    val idsToDelete = existingIds - newIds

                    idsToDelete.forEach { songbkRepo.deleteById(it) }
                    booksToInsert.forEach { songbkRepo.saveBook(it) }

                    prefsRepo.selectedBooks = newIds.joinToString(",")
                } else {
                    prefsRepo.isDataSelected = true
                    songbkRepo.saveBooks(books)
                    prefsRepo.selectedBooks = books.joinToString(",") { it.bookId.toString() }
                }

                fetchRemoteSongs(books.map { it.bookId })
            } catch (e: Exception) {
                Log.e("SaveBooks", "Failed to save books", e)
                _uiState.emit(UiState.Error("Failed to save books: ${e.message}"))
            }
        }
    }

    private suspend fun fetchRemoteSongs(bookIds: List<Int>) {
        try {
            Log.d("TAG", "Starting song fetch for ${bookIds.size} books")
            withContext(Dispatchers.IO) {
                songbkRepo.fetchAndSaveSongs(bookIds)
            }

            prefsRepo.isDataLoaded = true
            Log.d("TAG", "Song fetch and save completed")
            _uiState.tryEmit(UiState.Saved)

        } catch (e: Exception) {
            Log.e("TAG", "Song fetch failed: ${e.message}", e)
            _uiState.tryEmit(UiState.Saved)
        }
    }

    fun toggleBookSelection(book: Selectable<BookEntity>) {
        _books.value = _books.value.map {
            if (it.data.bookId == book.data.bookId) it.copy(isSelected = !it.isSelected) else it
        }
    }
}